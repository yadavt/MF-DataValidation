try:
    from unittest import mock
except ImportError:
    import mock


# flake8: noqa
